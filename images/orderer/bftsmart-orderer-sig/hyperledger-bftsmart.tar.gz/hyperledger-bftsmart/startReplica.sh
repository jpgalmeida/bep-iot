#!/bin/bash

IFS=',' read -r -a reps <<< "$BFTSMART_REPLICAS"
printf "%s\n" "${reps[@]}" > config/hosts.config

java -cp dist/BFT-Proxy.jar:lib/* bft.BFTNode $@
