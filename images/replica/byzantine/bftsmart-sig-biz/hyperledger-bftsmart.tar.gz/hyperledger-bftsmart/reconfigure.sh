#!/bin/bash
java -cp lib/BFT-SMaRt.jar:lib/* bftsmart.reconfiguration.VMServices $@
