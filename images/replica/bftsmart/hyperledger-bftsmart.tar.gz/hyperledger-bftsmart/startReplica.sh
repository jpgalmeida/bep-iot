#!/bin/bash

IFS=',' read -r -a reps <<< "$BFTSMART_REPLICAS"
printf "%s\n" "${reps[@]}" > config/hosts.config

printf "%s\n%s\n%s\n%s\n%s\n%s\n" \
	"MSPID=$BFTSMART_ORDERER_MSPID" \
	"CERTIFICATE=$BFTSMART_REPLICA_CERTIFICATE" \
	"PRIVKEY=$BFTSMART_REPLICA_PRIVKEY" \
	"PARELLELISM=$BFTSMART_PARELLELISM" \
	"BLOCKS_PER_THREAD=$BFTSMART_BLOCKS_PER_THREAD" \
	"RECEIVERS=$BFTSMART_RECEIVERS" > config/node.config

java -cp dist/BFT-Proxy.jar:lib/* bft.BFTNode $@
